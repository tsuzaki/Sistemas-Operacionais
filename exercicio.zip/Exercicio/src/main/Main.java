package main;

public class Main {
	
	static int i = 0;
	
    public static void main(String[] args) {
        new Thread(t1).start();
        new Thread(t2).start();
        new Thread(t3).start();
    }
 
    private static void gerarSenha(String name){
    	
    	 String[] caracteres ={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    	 String senha="";

    	 for (int i=0; i<10; i++){
    	     int j = (int)(Math.random()*caracteres.length);
    	     senha = senha + caracteres[j];
    	 }
    	  System.out.println("Senha gerada: " + senha + " - por: " + name);
    }
 
    private static Runnable t1 = new Runnable() {
        public void run() {
      
        	for(int i=0; i<10; i++){
        		gerarSenha("t1");
            }
        }
    };
    
    private static Runnable t2 = new Runnable() {
        public void run() {
      
        	for(int i=0; i<10; i++){
        		gerarSenha("t2");
            }
        }
    };
    
    private static Runnable t3 = new Runnable() {
        public void run() {
      
        	for(int i=0; i<10; i++){
        		gerarSenha("t3");
            }
        }
    };
 
    

}
